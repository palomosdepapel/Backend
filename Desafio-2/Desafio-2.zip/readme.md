COMENTARIOS SOBRE ESTE HANDS ON LAB

Es muy importante que tengas cuidado con las rutas, debido a que aún no estás trabajando con
paths absolutos, entonces, influye mucho si corremos el proyecto dentro de la carpeta handsOnLab o fuera de él. Corrobora siempre el nivel en el que te encuentras al momento de correr el código